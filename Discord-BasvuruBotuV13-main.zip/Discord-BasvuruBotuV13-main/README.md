# Discord.js v13 Başvuru Botu
Umut Bayraktar Youtube Özel Discord.js v13 Başvuru Botu Altyapısı.<br>
Glitch.com'da Kullanacak İseniz <b>.env</b> İsimli Dosyaya Bot Tokeninizi Yazın ve Kullanın.<br>
VDS veya PC'de Kullanacak İseniz <b>config.js</b> İsimli Dosyaya Bot Tokeninizi Yazın ve Kullanın.<br>
Projeyi VDS veya PC'ye Kurarsanız baslat.bat ile Projeyi Başlata Bilirsniz.<br>
<br><br>
Umut Bayraktar Youtube: <a href="https://www.youtube.com/UmutBayraktarYT">Abone Ol</a><br>
Discord: <a href="https://discord.gg/58e5H4try3">Katıl</a>
<br><br>
Code Share Discord: <a href="https://discord.gg/6XGqdgE">KATIL</a>
<br><br>
<h3>YILDIZ ATARSANIZ MUTLU OLURUM</h3>
